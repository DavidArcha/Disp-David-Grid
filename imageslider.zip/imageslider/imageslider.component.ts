import { Component } from '@angular/core';

@Component({
  selector: 'app-imageslider',
  templateUrl: './imageslider.component.html',
  styleUrl: './imageslider.component.scss',
})
export class ImagesliderComponent {
  // Array of images with URLs and optional alt texts
  images = [
    { id: 1, url: 'assets/images/1.jpg', altText: 'Image 1' },
    { id: 2, url: 'assets/images/2.jpg', altText: 'Image 2' },
    { id: 3, url: 'assets/images/3.jpg', altText: 'Image 3' },
    { id: 4, url: 'assets/images/4.jpg', altText: 'Image 4' },
    { id: 5, url: 'assets/images/5.jpg', altText: 'Image 5' },
    { id: 6, url: 'assets/images/6.jpg', altText: 'Image 6' },
  ];

  currentSlide = 0;
  isPreviewOpen = false;
  previewImageUrl = '';

  // Navigate to the previous slide
  prevSlide() {
    this.currentSlide =
      this.currentSlide > 0 ? this.currentSlide - 1 : this.images.length - 1;
  }

  // Navigate to the next slide
  nextSlide() {
    this.currentSlide =
      this.currentSlide < this.images.length - 1 ? this.currentSlide + 1 : 0;
  }

  // Open image preview
  openPreview(imageUrl: string) {
    this.isPreviewOpen = true;
    this.previewImageUrl = imageUrl;
  }

  // Close image preview
  closePreview() {
    this.isPreviewOpen = false;
    this.previewImageUrl = '';
  }

  // Upload more images (placeholder for actual logic)
  uploadImage() {
    // Logic to upload new images
  }

  // Delete current image
  deleteImage() {
    this.images.splice(this.currentSlide, 1);
    if (this.currentSlide >= this.images.length) {
      this.currentSlide = 0;
    }
  }
}
