import { HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { of, Subscription } from 'rxjs';
import { ImageUploadService } from '../image-upload.service';
import { ImageConverterService } from '../image-converter.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import {
  PDFDocumentProxy,
  PDFPageProxy,
} from 'pdfjs-dist/types/src/display/api';

declare const pdfjsLib: any; // Declare the external pdfjsLib if loaded through <script> in index.html

@Component({
  selector: 'app-multiple-image-upload',
  templateUrl: './multiple-image-upload.component.html',
  styleUrl: './multiple-image-upload.component.scss',
})
export class MultipleImageUploadComponent {
  selectedImages: any[] = [];
  totalSize: number = 0;
  maxTotalSize: number = 50 * 1024 * 1024; // 50MB
  isUploading: boolean = false; // Track if uploading is in progress
  uploadProgress: string = '';
  uploadedCount = 0; // Store the count of successfully uploaded images
  subscriptions: Subscription[] = []; // Store subscriptions for cancellation
  uploadCanceled: boolean = false; // Track if upload was canceled
  uploadProgressArray: number[] = []; // Holds upload progress for each image
  uploadStatus: string[] = []; // Holds 'success' or 'error' for each image
  uploadSummaryVisible: boolean = false; // Flag to display the upload summary
  isDragOver: boolean = false;
  @ViewChild('pdfCanvas', { static: true })
  pdfCanvas!: ElementRef<HTMLCanvasElement>;
  pdfThumbnail: SafeUrl | null = null;
  public failedCount: number = 0;
  public totalSelectedFiles: number = 0;
  public uploadProgressMessage: string = '';
  public completedMessage: string = '';
  fileSize: any;
  public currentUploadingIndex: number = -1; // Index of the currently uploading image

  @ViewChild('fileInput') fileInput!: ElementRef; // Reference to file input element

  constructor(
    private imageUploadService: ImageUploadService,
    private imageConverterService: ImageConverterService,
    private sanitizer: DomSanitizer
  ) {}

  // Existing functionality for selecting images
  onSelectImage(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.handleFiles(input.files);
      // Reset the input value to allow re-uploading the same file if needed
      input.value = '';
    }
  }

  // Enhancement: Handle files for drag-and-drop and file input selection
  handleFiles(files: FileList): void {
    const duplicateFiles: string[] = [];

    // Convert FileList to an array and iterate over each file
    Array.from(files).forEach((file, index) => {
      if (this.isDuplicateFile(file)) {
        // Collect duplicate file names to notify the user
        duplicateFiles.push(file.name);
      } else {
        const fileSize = file.size;
        if (fileSize + this.totalSize > this.maxTotalSize) {
          alert('Cannot add more images. Total size exceeds 50MB.');
          return;
        }
        const fileType = file.type;
        if (
          fileType.includes('pdf') ||
          file.type === 'application/pdf' ||
          file.name.toLowerCase().endsWith('.pdf')
        ) {
          this.renderPDF(file);
        } else {
          // Use ImageConverterService to generate preview
          this.imageConverterService
            .convertToPng(file)
            .then((previewUrl) => {
              this.selectedImages.push({
                name: file.name,
                size: fileSize,
                file: file,
                previewUrl: previewUrl, // Add preview URL
                id: this.generateUniqueId(),
                oversized: fileSize > 5 * 1024 * 1024,
                type: fileType,
                progress: 0, // Initialize progress
              });
            })
            .catch((error) => {
              console.error('Error generating preview:', error);
            });
        }

        this.uploadStatus.push(''); // Initialize upload status
        this.uploadProgressArray.push(0); // Initialize upload progress
        this.totalSize += file.size;
      }
    });

    // Notify user if there are duplicate files
    if (duplicateFiles.length > 0) {
      alert(
        `The following files are duplicates and were not added: ${duplicateFiles.join(
          ', '
        )}`
      );
    }
  }

  renderPDF(file: File) {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');

    const loadingTask = pdfjsLib.getDocument(URL.createObjectURL(file));
    loadingTask.promise
      .then((pdf: PDFDocumentProxy) => {
        // Specify type as PDFDocumentProxy
        pdf.getPage(1).then((page: PDFPageProxy) => {
          // Specify type as PDFPageProxy
          const viewport = page.getViewport({ scale: 1.5 });
          canvas.height = viewport.height;
          canvas.width = viewport.width;

          const renderContext = {
            canvasContext: context!,
            viewport: viewport,
          };

          page
            .render(renderContext)
            .promise.then(() => {
              // Convert the rendered canvas to an image URL for preview
              const imageUrl = canvas.toDataURL('image/png');

              // Add the image to selectedImages array
              this.selectedImages.push({
                name: file.name,
                size: file.size,
                file: file,
                previewUrl: imageUrl,
                id: this.generateUniqueId(),
                oversized: file.size > 5 * 1024 * 1024, // Check for oversized condition
                errorMessage: '',
                progress: 0, // Initialize progress
              });

              // Remove the canvas from DOM to clean up
              canvas.remove();
            })
            .catch((error) => {
              console.error('Error rendering PDF:', error);
            });
        });
      })
      .catch((error: any) => {
        console.error('Error loading PDF document:', error);
      });
  }

  // Method to check for duplicate files based on name and size
  isDuplicateFile(newFile: File): boolean {
    return this.selectedImages.some(
      (existingFile) =>
        existingFile.name === newFile.name && existingFile.size === newFile.size
    );
  }

  // Remove selected image
  removeImage(index: number) {
    if (!this.isUploading) {
      this.totalSize -= this.selectedImages[index].size;
      this.selectedImages.splice(index, 1);
      this.uploadProgressArray.splice(index, 1);
      this.uploadStatus.splice(index, 1);
    }
  }

  // Trigger file input for adding more images
  onAddMoreImages() {
    this.fileInput.nativeElement.click();
  }

  // Upload images one by one with delay (testing)
  async onUploadImages() {
    if (this.selectedImages.length === 0) {
      alert('Please select images to upload.');
      return;
    }

    this.isUploading = true;
    this.uploadCanceled = false;
    this.uploadedCount = 0;
    this.failedCount = 0;

    for (const [index, image] of this.selectedImages.entries()) {
      if (image.oversized) continue;

      if (this.uploadCanceled) {
        this.uploadProgress = 'Uploading stopped';
        break;
      }

      this.currentUploadingIndex = index; // Set the current index
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const multipartSub = this.uploadMultipart(image.id, image.file).subscribe(
        (event: any) => {
          this.handleUploadResponse(event, index); // Pass index to update specific file progress          
        },
        (error) => {
          this.handleUploadError(error, index, image);
        }
      );
      this.subscriptions.push(multipartSub);

      this.uploadedCount++;
      this.currentUploadingIndex = -1; // Reset after completion
    }

    if (!this.uploadCanceled) {
      this.updateCompletionMessage();
      this.isUploading = false;
      this.uploadSummaryVisible = true;
    }
  }

  handleUploadError(error: any, index: number, image: any) {
    if (error.status === 500) {
      // Mark the file as infected and set a custom error message
      this.uploadStatus[index] = 'infected';
      this.selectedImages[index].errorMessage = 'infected file cannot upload';
      this.failedCount++;
      this.updateProgressMessage();
    } else {
      // General error handling
      console.error('Upload failed-1', error);
      this.uploadStatus[index] = 'error';
      this.failedCount++;
      this.updateProgressMessage();
    }
  }

  handleUploadResponse(event: any, index: number) {
    if (event.type === HttpEventType.Response) {
      // Increment the uploaded count only after a response is received for each image
      // this.uploadedCount++;
      // this.uploadProgress = `Uploading images: ${this.uploadedCount}/${this.selectedImages.length}`;
      this.uploadStatus[index] = 'success';
      this.updateProgressMessage();
      // Check if all images have been uploaded
      if (this.uploadedCount === this.selectedImages.length) {
        this.uploadProgress = 'Upload complete!-1';
        //this.resetUploadState(); // Reset state after upload completes
      }
    } else if (event instanceof HttpErrorResponse) {
      // Log detailed error information to the console
      console.error('Error during upload:', event.error);
      this.uploadStatus[index] = 'error';
      this.failedCount++;
      this.updateProgressMessage();
    }
  }

  uploadMultipart(id: number, file: File) {
    const formData: FormData = new FormData();
    formData.append('id', id.toString()); // Add unique integer ID
    formData.append('file', file);

    return this.imageUploadService.uploadImageMultipart(formData);
  }

  updateProgressMessage(): void {
    const percentage =
      ((this.uploadedCount + this.failedCount) / this.selectedImages.length) *
      100;
    this.uploadProgress = `${percentage.toFixed(0)}% - Files Uploading 123: ${
      this.uploadedCount + this.failedCount
    }/${this.selectedImages.length}`;
  }

  updateCompletionMessage(): void {
    this.uploadProgress = `Upload completed. Total Selected Files: ${this.selectedImages.length}, ${this.uploadedCount} files uploaded, ${this.failedCount} files failed to upload.`;
  }
  generateUniqueId(): number {
    // Generate a random integer between 1 and 999999 (or any desired range)
    return Math.floor(Math.random() * 999999) + 1;
  }

  // Utility function to create a delay of specified milliseconds
  delay(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Cancel the ongoing upload process
  onCancelUpload() {
    this.uploadCanceled = true; // Mark as canceled
    this.uploadProgress = 'Uploading stopped'; // Set progress message
    this.resetUploadState(); // Reset state after cancel
    // Unsubscribe from all active uploads
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

  // Reset the state after cancel or after upload completes
  resetUploadState() {
    this.isUploading = false;
    this.selectedImages = []; // Clear images list
    this.totalSize = 0; // Reset the total size
    this.uploadedCount = 0; // Reset upload count
    this.uploadStatus = [];
  }

  //Handle drag-over event
  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.isDragOver = true;
  }

  onDragLeave(event: DragEvent): void {
    this.isDragOver = false;
  }

  //Handle drop event
  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.isDragOver = false;
    const files = event.dataTransfer?.files;
    if (files) {
      this.handleFiles(files);
    }
  }

  hasOversizedFiles(): boolean {
    return this.selectedImages.some((image) => image.oversized);
  }
}
