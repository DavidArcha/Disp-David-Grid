import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomButtonRendererComponent } from './custom-button-renderer.component';

describe('CustomButtonRendererComponent', () => {
  let component: CustomButtonRendererComponent;
  let fixture: ComponentFixture<CustomButtonRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomButtonRendererComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomButtonRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
