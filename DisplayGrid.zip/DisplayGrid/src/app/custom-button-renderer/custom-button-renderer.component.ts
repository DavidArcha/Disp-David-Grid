import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-button-renderer',
  templateUrl: './custom-button-renderer.component.html',
  styleUrl: './custom-button-renderer.component.scss'
})
export class CustomButtonRendererComponent {
  params: any;

  agInit(params: any): void {
    this.params = params;
  }

  onClick() {
    console.log('Row Data:', this.params.data);
  }
}