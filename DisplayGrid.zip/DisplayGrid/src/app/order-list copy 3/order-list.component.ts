import { Component, OnInit } from '@angular/core';
import { ColDef, GridApi } from 'ag-grid-community';
import { ToggleRendererComponent } from '../toggle-renderer/toggle-renderer.component';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.scss'],
})
export class OrderListComponent implements OnInit {
  gridApi!: GridApi;
  rowData: any[] = []; // Main data for the grid
  columnDefs: ColDef[] = []; // Column definitions
  expandedRowId: string | null = null; // Track the currently expanded row's ID
  toggleList: any[] = []; // Store data from toggle-list.json

  // Default column definition for grid
  defaultColDef: ColDef = {
    sortable: true,
    resizable: true,
    filter: true,
  };

  gridOptions = {
    getRowId: (params: any) => params.data.id, // Use a unique `id` field for all rows
    getRowStyle: (params: any) => {
      if (params.data.isDetail) {
        return { background: '#f9f9f9', fontStyle: 'italic' }; // Custom styling for expanded rows
      }
      return undefined;
    },
    components: {
      toggleRenderer: ToggleRendererComponent, // Register custom renderer
    },
  };

  ngOnInit(): void {
    this.columnDefs = [
      {
        headerName: '',
        field: 'expanded',
        cellRenderer: 'toggleRenderer',
        width: 50,
        cellRendererParams: {
          onToggle: this.toggleRow.bind(this), // Bind toggleRow function
        },
      },
      { field: 'orderno', headerName: 'Order No' },
      { field: 'ordertrackno', headerName: 'Order Track No' },
      { field: 'labeldate', headerName: 'Label Date' },
      { field: 'custno', headerName: 'Customer No' },
      { field: 'perid', headerName: 'Period' },
    ];

    // Fetch initial data for the grid
    fetch('/assets/jsonFiles/orders-list.json')
      .then((response) => response.json())
      .then((data) => {
        this.rowData = data.map((row: any, index: number) => ({
          ...row,
          id: `row-${index}`, // Add unique ID for each row
          expanded: false, // Add expanded state
          isDetail: false, // Track if the row is a detail row
        }));
      });

    // Fetch data from toggle-list.json
    fetch('/assets/jsonFiles/toggle-list.json')
      .then((response) => response.json())
      .then((data) => {
        this.toggleList = data; // Store the toggle list data
      });
  }

  onGridReady(params: any): void {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }

  toggleRow(data: any): void {
    const index = this.rowData.indexOf(data);
  
    // If the current row is already expanded, collapse it
    if (this.expandedRowId === data.orderno) {
      const detailRow = this.rowData[index + 1];
      if (detailRow?.isDetail) {
        this.rowData.splice(index + 1, 1); // Remove the expanded row
        data.expanded = false; // Collapse the parent row
        this.gridApi.applyTransaction({ remove: [detailRow] });
        this.expandedRowId = null; // Reset the expanded row ID
      }
      return;
    }
  
    // Collapse previously expanded row
    if (this.expandedRowId) {
      const prevExpandedRowIndex = this.rowData.findIndex(
        (row) => row.orderno === this.expandedRowId
      );
      if (prevExpandedRowIndex !== -1) {
        const prevDetailRow = this.rowData[prevExpandedRowIndex + 1];
        if (prevDetailRow?.isDetail) {
          this.rowData.splice(prevExpandedRowIndex + 1, 1); // Remove previous expanded row
          this.rowData[prevExpandedRowIndex].expanded = false; // Collapse the parent row
          this.gridApi.applyTransaction({ remove: [prevDetailRow] });
        }
      }
    }
  
    // Find matching data in toggleList.json
    const toggleData = this.toggleList.find(
      (item: any) => item.orderno === data.orderno
    );
  
    // Expand the current row
    const expandedRow = {
      orderno: data.orderno, // Use orderno as the ID
      isDetail: true, // Mark as a detail row
      supplierName: toggleData?.SupplierName || 'N/A',
      sid: toggleData?.SID || 'N/A',
    };
    this.rowData.splice(index + 1, 0, expandedRow); // Add to data array
    data.expanded = true;
  
    // Update grid
    this.gridApi.applyTransaction({ add: [expandedRow], addIndex: index + 1 });
    this.expandedRowId = data.orderno; // Track the newly expanded row ID
  }
  

  getRowHeight(params: any): number {
    if (params.data.isDetail) {
      return 100; // Larger height for expanded rows
    }
    return 30;
  }
}
