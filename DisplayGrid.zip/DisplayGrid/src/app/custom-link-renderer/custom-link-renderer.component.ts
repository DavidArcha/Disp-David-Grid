import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-link-renderer',
  templateUrl: './custom-link-renderer.component.html',
  styleUrl: './custom-link-renderer.component.scss'
})
export class CustomLinkRendererComponent {
  params: any;

  agInit(params: any): void {
    this.params = params;
  }

  onClick() {
    console.log('Row Data:', this.params.data);
  }
}
