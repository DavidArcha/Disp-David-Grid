import { Component, OnInit } from '@angular/core';
import { ColDef, GridApi } from 'ag-grid-community';
import { ToggleRendererComponent } from '../toggle-renderer/toggle-renderer.component';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.scss'],
})
export class OrderListComponent implements OnInit {
  gridApi!: GridApi;
  rowData: any[] = []; // Main data for the grid
  columnDefs: ColDef[] = []; // Column definitions
  expandedRowId: string | null = null; // Track the currently expanded row's ID
  toggleList: any[] = []; // Store data from toggle-list.json

  // Default column definition for grid
  defaultColDef: ColDef = {
    sortable: true,
    resizable: true,
    filter: true,
  };

  gridOptions = {
    getRowId: (params: any) => {
      if (params.data.isDetail) {
        return `${params.data.id}`; // Use unique ID for expanded rows
      }
      return `${params.data.orderno}`; // Use orderno for parent rows
    },
    getRowStyle: (params: any) => {
      if (params.data.isDetail) {
        return { background: '#f9f9f9', fontStyle: 'italic' }; // Custom styling for expanded rows
      }
      return undefined;
    },
    components: {
      toggleRenderer: ToggleRendererComponent, // Register custom renderer
    },
  };
  

  ngOnInit(): void {
    this.columnDefs = [
      {
        headerName: '',
        field: 'expanded',
        cellRenderer: 'toggleRenderer',
        width: 50,
        cellRendererParams: {
          onToggle: this.toggleRow.bind(this), // Bind toggleRow function
        },
      },
      { field: 'orderno', headerName: 'Order No' },
      { field: 'ordertrackno', headerName: 'Order Track No' },
      { field: 'labeldate', headerName: 'Label Date' },
      { field: 'custno', headerName: 'Customer No' },
      { field: 'perid', headerName: 'Period' },
    ];

    // Fetch initial data for the grid
    fetch('/assets/jsonFiles/orders-list.json')
      .then((response) => response.json())
      .then((data) => {
        this.rowData = data.map((row: any, index: number) => ({
          ...row,
          id: `row-${index}`, // Add unique ID for each row
          expanded: false, // Add expanded state
          isDetail: false, // Track if the row is a detail row
        }));
      });

    // Fetch data from toggle-list.json
    fetch('/assets/jsonFiles/toggle-list.json')
      .then((response) => response.json())
      .then((data) => {
        this.toggleList = data; // Store the toggle list data
      });
  }

  onGridReady(params: any): void {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
  }

  toggleRow(data: any): void {
    const parentIndex = this.rowData.findIndex((row) => row.orderno === data.orderno);
  
    // If the row is already expanded, collapse it
    if (this.expandedRowId === data.orderno) {
      this.collapseRow(parentIndex);
      this.expandedRowId = null; // Reset expanded row ID
      return;
    }
  
    // Collapse the previously expanded row (if any)
    if (this.expandedRowId) {
      const prevParentIndex = this.rowData.findIndex((row) => row.orderno === this.expandedRowId);
      this.collapseRow(prevParentIndex);
    }
  
    // Expand the current row
    this.expandRow(data, parentIndex);
  }
  
  collapseRow(index: number): void {
    const detailRow = this.rowData[index + 1];
    if (detailRow?.isDetail) {
      this.rowData.splice(index + 1, 1); // Remove the detail row
      this.rowData[index].expanded = false; // Reset parent row's expanded state
      this.gridApi.applyTransaction({ remove: [detailRow] });
    }
  }
  
  expandRow(data: any, index: number): void {
    // Find matching data in toggleList.json
    const toggleData = this.toggleList.find((item) => item.orderno === data.orderno);
  
    const expandedRow = {
      id: `${data.orderno}-detail`, // Unique ID for expanded row
      isDetail: true, // Mark as detail row
      supplierName: toggleData?.SupplierName || 'N/A',
      sid: toggleData?.SID || 'N/A',
    };
  
    this.rowData.splice(index + 1, 0, expandedRow); // Insert the detail row directly below parent row
    data.expanded = true; // Set parent row as expanded
    this.gridApi.applyTransaction({ add: [expandedRow], addIndex: index + 1 });
    this.expandedRowId = data.orderno; // Track the currently expanded row
  }
  
  getRowHeight(params: any): number {
    if (params.data.isDetail) {
      return 50; // Larger height for expanded rows
    }
    return 30;
  }
}
