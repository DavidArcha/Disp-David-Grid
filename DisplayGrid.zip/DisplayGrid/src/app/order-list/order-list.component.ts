import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { CustomButtonRendererComponent } from '../custom-button-renderer/custom-button-renderer.component';
import { CustomCheckboxRendererComponent } from '../custom-checkbox-renderer/custom-checkbox-renderer.component';
import { CustomLinkRendererComponent } from '../custom-link-renderer/custom-link-renderer.component';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.scss'
})
export class OrderListComponent {
  columnDefs = [
    {
      headerName: 'Order No',
      field: 'orderno',
      cellRenderer: CustomLinkRendererComponent
    },
    { headerName: 'Order Track No', field: 'ordertrackno' },
    { headerName: 'Label Date', field: 'labeldate' },
    { headerName: 'Customer No', field: 'custno' },
    { headerName: 'Period', field: 'perid' },
    { headerName: 'Catalog', field: 'catlog' },
    { headerName: 'Description', field: 'description' },
    { headerName: 'Label Number', field: 'labelnumber' },
    {
      headerName: 'Download',
      field: 'download',
      cellRenderer: CustomCheckboxRendererComponent
    },
    {
      headerName: 'Download PDF',
      field: 'downloadpdf',
      cellRenderer: CustomButtonRendererComponent,
      cellRendererParams: {
        icon: 'fa-file-pdf',
        buttonText: '',
        action: 'downloadPdf'
      }
    },
    {
      headerName: 'PDF Status',
      field: 'pdfstatus',
      cellRenderer: (params: any) => {
        return params.value ? '<i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>';
      }
    },
    {
      headerName: 'Download XML',
      field: 'downloadxml',
      cellRenderer: CustomButtonRendererComponent,
      cellRendererParams: {
        icon: 'fa-file-code',
        buttonText: '',
        action: 'downloadXml'
      }
    },
    {
      headerName: 'View PDF',
      field: 'viewpdf',
      cellRenderer: CustomButtonRendererComponent,
      cellRendererParams: {
        buttonText: 'View PDF',
        action: 'viewPdf'
      }
    }
  ];

  rowData: any[] = [];

  constructor(private http: HttpClient) {
    this.http.get('/assets/jsonFiles/orders-list.json').subscribe((data: any) => {
      this.rowData = data;
    });
  }

  handleRowAction(action: string, rowData: any) {
    console.log(`Action: ${action}`, rowData);
  }
}
