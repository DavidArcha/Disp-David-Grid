import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { CustomRadioButtonRendererComponent } from '../custom-radio-button-renderer/custom-radio-button-renderer.component';

@Component({
  selector: 'app-supplier-search',
  templateUrl: './supplier-search.component.html',
  styleUrl: './supplier-search.component.scss',
})
export class SupplierSearchComponent {
  supplierNumber: string = '';
  supplierName: string = '';
  supplierData: any[] = [];
  selectedRow: any = null;

  columnDefs = [
    {
      headerName: 'Select',
      field: 'select',
      cellRenderer: CustomRadioButtonRendererComponent,
    },
    { headerName: 'Supplier Number', field: 'SupplierNumber' },
    { headerName: 'Supplier Name', field: 'SupplierName' },
    { headerName: 'SID', field: 'SID' },
  ];

  constructor(private http: HttpClient) {}

  onSearch() {
    this.http.get('/assets/jsonFiles/supplier-list.json').subscribe((data: any) => {
      const suppliers = data as any[];
      if (this.supplierNumber) {
        this.supplierData = suppliers.filter((supplier) =>
          supplier.SupplierNumber.includes(this.supplierNumber)
        );
      } else if (this.supplierName) {
        this.supplierData = suppliers.filter((supplier) =>
          supplier.SupplierName.toLowerCase().includes(
            this.supplierName.toLowerCase()
          )
        );
      }
    });
  }

  gridOptions = {
    context: {
      componentParent: this
    }
  };
  
  onRowSelected(rowData: any) {
    this.selectedRow = rowData;
    console.log('Selected Row Data:', rowData);
  }

  onAccept() {
    if (this.selectedRow) {
      console.log('Accepted Row Data:', this.selectedRow);
    }
  }

  onReject() {
    if (this.selectedRow) {
      console.log('Rejected Row Data:', this.selectedRow);
    }
  }
}
