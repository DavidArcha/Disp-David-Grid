import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AgGridModule } from 'ag-grid-angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrderListComponent } from './order-list/order-list.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomLinkRendererComponent } from './custom-link-renderer/custom-link-renderer.component';
import { CustomCheckboxRendererComponent } from './custom-checkbox-renderer/custom-checkbox-renderer.component';
import { CustomButtonRendererComponent } from './custom-button-renderer/custom-button-renderer.component';
import { SupplierSearchComponent } from './supplier-search/supplier-search.component';
import { CustomRadioButtonRendererComponent } from './custom-radio-button-renderer/custom-radio-button-renderer.component';

@NgModule({
  declarations: [
    AppComponent,
    OrderListComponent,
    CustomLinkRendererComponent,
    CustomCheckboxRendererComponent,
    CustomButtonRendererComponent,
    SupplierSearchComponent,
    CustomRadioButtonRendererComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AgGridModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
