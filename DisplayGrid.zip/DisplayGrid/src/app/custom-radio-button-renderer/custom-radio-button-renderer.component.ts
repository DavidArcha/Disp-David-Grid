import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-radio-button-renderer',
  templateUrl: './custom-radio-button-renderer.component.html',
  styleUrl: './custom-radio-button-renderer.component.scss'
})
export class CustomRadioButtonRendererComponent {
  params: any;

  agInit(params: any): void {
    this.params = params;
  }

  onSelect() {
    if (this.params && this.params.context && this.params.context.componentParent) {
      this.params.context.componentParent.onRowSelected(this.params.data);
    } else {
      console.error('componentParent is not defined.');
    }
  }
}