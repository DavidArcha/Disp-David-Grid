import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomRadioButtonRendererComponent } from './custom-radio-button-renderer.component';

describe('CustomRadioButtonRendererComponent', () => {
  let component: CustomRadioButtonRendererComponent;
  let fixture: ComponentFixture<CustomRadioButtonRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomRadioButtonRendererComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomRadioButtonRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
