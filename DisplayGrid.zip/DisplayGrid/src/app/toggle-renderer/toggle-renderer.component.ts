import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-toggle-renderer',
  templateUrl: './toggle-renderer.component.html',
  styleUrls: ['./toggle-renderer.component.scss']
})
export class ToggleRendererComponent implements ICellRendererAngularComp {
  params: any;

  agInit(params: any): void {
    this.params = params;
  }

  refresh(params: any): boolean {
    this.params = params;
    return true;
  }

  onClick(event: any) {
    if (this.params && this.params.onClick instanceof Function) {
      this.params.onClick(this.params.data);
    }
  }
}