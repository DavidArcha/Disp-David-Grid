import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CustomButtonRendererComponent } from '../custom-button-renderer/custom-button-renderer.component';
import { CustomCheckboxRendererComponent } from '../custom-checkbox-renderer/custom-checkbox-renderer.component';
import { CustomLinkRendererComponent } from '../custom-link-renderer/custom-link-renderer.component';
import { ColDef, GridOptions, ICellRendererParams } from 'ag-grid-community';
import { MyDetailCellRendererComponent } from '../my-detail-cell-renderer/my-detail-cell-renderer.component';

interface OrderRow {
  orderno: string;
  ordertrackno: string;
  labeldate: string;
  custno: string;
  perid: string;
  expanded?: boolean; // Optional flag for expanded state
}

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.scss',
})
export class OrderListComponent implements OnInit {
  rowData: OrderRow[] = [];

  ngOnInit(): void {
   // Fetch data from JSON file and add an `expanded` flag
   fetch('/assets/jsonFiles/orders-list.json')
   .then((response) => response.json())
   .then((data: OrderRow[]) => {
     this.rowData = data.map((row: OrderRow) => ({
       ...row,
       expanded: false, // Initialize each row as not expanded
     }));
   });
  }
  toggleRow(index: number): void {
    // Toggle the expanded state of the clicked row
    this.rowData[index].expanded = !this.rowData[index].expanded;
  }
}
