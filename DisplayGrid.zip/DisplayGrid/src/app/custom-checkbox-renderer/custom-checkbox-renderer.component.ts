import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-checkbox-renderer',
  templateUrl: './custom-checkbox-renderer.component.html',
  styleUrl: './custom-checkbox-renderer.component.scss'
})
export class CustomCheckboxRendererComponent {
  params: any;

  agInit(params: any): void {
    this.params = params;
  }

  onChange(event: any) {
    console.log('Checkbox checked:', event.target.checked, 'Row Data:', this.params.data);
  }
}