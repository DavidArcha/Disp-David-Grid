import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-nestedrow',
  templateUrl: './nestedrow.component.html',
  styleUrls: ['./nestedrow.component.scss']
})
export class NestedrowComponent implements OnInit {
  public rowData: any[] = []; // Main data for AG-Grid
  public toggleData: any[] = []; // Supplier data for toggle
  public displayData: any[] = []; // Data for AG-Grid display (including supplier rows)
  public columnDefs = [
    {
      field: '',
      headerName: '',
      width: 50,
      cellRenderer: (params: any) => {
        // Only show button in main rows (not expanded rows)
        if (!params.data.isExpandedRow) {
          const button = document.createElement('button');
          button.innerText = this.expandedRow === params.data.orderId ? '-' : '+';
          button.style.cursor = 'pointer';
          button.addEventListener('click', () => {
            this.toggleRow(params.data.orderId);
          });
          return button;
        }
        return ''; // Return empty for expanded rows
      }
    },
    { field: 'orderId', headerName: 'Order ID', width: 120 },
    { field: 'productName', headerName: 'Product Name', width: 250 },
    {
      field: 'quantity',
      headerName: 'Quantity',
      width: 120,
      valueGetter: (params: any) => {
        // Return blank for expanded rows
        return params.data.isExpandedRow ? '' : params.data.quantity;
      }
    },
    {
      field: 'price',
      headerName: 'Price ($)',
      width: 120,
      valueGetter: (params: any) => {
        // Return blank for expanded rows
        return params.data.isExpandedRow ? '' : params.data.price;
      }
    }
  ];

  // Track the currently expanded row
  public expandedRow: number | null = null;

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    // Load main data
    this.http.get<any[]>('/assets/jsonFiles/orders-list.json').subscribe((orders) => {
      this.rowData = orders;
      console.log('Orders loaded:', this.rowData);
      this.updateDisplayData(); // Initial data setup
    });

    // Load toggle data
    this.http.get<any[]>('/assets/jsonFiles/toggle-list.json').subscribe((suppliers) => {
      this.toggleData = suppliers;
      console.log('Toggle data loaded:', this.toggleData);
    });
  }

  // Toggle logic to show/hide supplier row
  toggleRow(orderId: number): void {
    console.log('Toggle button clicked for orderId:', orderId);

    if (this.expandedRow === orderId) {
      // If the clicked row is already expanded, collapse it
      console.log('Hiding supplier row for orderId:', orderId);
      this.expandedRow = null;
    } else {
      // Expand the clicked row and collapse others
      console.log('Showing supplier row for orderId:', orderId);
      this.expandedRow = orderId;
    }

    this.updateDisplayData(); // Update display data after toggling
  }

  // Update display data with supplier rows
  updateDisplayData(): void {
    console.log('Updating displayData...');
    console.log('Currently expanded row:', this.expandedRow);

    this.displayData = []; // Clear displayData to rebuild it
    for (const row of this.rowData) {
      this.displayData.push(row); // Add main row
      if (this.expandedRow === row.orderId) {
        // Find supplierName for the current orderId
        const supplierRow = this.toggleData.find((s) => s.orderId === row.orderId);
        if (supplierRow) {
          console.log('Adding supplier row for orderId:', row.orderId, 'Supplier:', supplierRow);
          this.displayData.push({
            isExpandedRow: true, // Flag to identify expanded rows
            orderId: '', // Empty to align properly
            productName: `${supplierRow.supplierName}`, // Only display supplier name
            quantity: null, // Use null to avoid "Invalid Number"
            price: null // Use null to avoid "Invalid Number"
          });
        } else {
          console.warn('No supplier data found for orderId:', row.orderId);
        }
      }
    }
    console.log('Updated displayData:', this.displayData);
    this.cdr.detectChanges(); // Notify Angular to refresh the grid
  }
}
