import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NestedrowComponent } from './nestedrow.component';

describe('NestedrowComponent', () => {
  let component: NestedrowComponent;
  let fixture: ComponentFixture<NestedrowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NestedrowComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NestedrowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
